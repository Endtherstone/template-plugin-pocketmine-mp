<?php

namespace uio;

use pocketmine\plugin\pluginBase;
use pocketmine\command\{command, commandsender};
use pocketmine\player;
use pocketmine\server;
use pocketmine\detaBase;

class main extends pluginBase{
    public function onenable(){
        $this->getlogger()->info("enable runing on server");
    }
    
    public function ondisble(){
        $this->getlogger()->info("disble");
    }
    
    public function oncommand(commandsender $sender, command $cmd, string $label, array $args) : bool{
        if($cmd->getname() == "uio"){
            if($sender instanceof player){
                $sender->sendmessage("use command in game");
                return true;
            }
            $sender->sendmessage("[uio]>plugin no function");
        }
        return true;
    }
}